<script language="javascript" type="text/javascript">
<!--//
function confirmation_internal() {
	var cancel = confirm("Selecting Cancel does not save any changes you have made.\n\n Are you sure you want to cancel this action?");
	if (cancel == true) {	
<% // actionConfig is defined in 'strutsConfig.inc'
	org.apache.struts.action.ActionForward cancelAction = actionConfig.findForward("cancel");
	if( cancelAction != null ) {
%>
		window.location.href = "<html:rewrite page='<%= cancelAction.getPath() %>' />";
<%	} else { // cancelAction not found
	 	String fullActionPath = actionPath + ".do";
%>
	 	<bean:define id="methodView" value="view"/>
		window.location.href = "<html:rewrite page='<%= fullActionPath %>' paramId='method' paramName='methodView' />";
<%	} // cancelAction
%>
	}
}
//-->
</SCRIPT>
