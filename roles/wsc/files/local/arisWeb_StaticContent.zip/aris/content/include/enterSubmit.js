<script language="JavaScript1.2" type="text/javascript">
<!--//

function enterSubmit(submitButton)
{
	var key;

	if (navigator.appName=='Microsoft Internet Explorer') key = window.event.keyCode;

	else if (navigator.appName=='Netscape' || navigator.vendorSub!=null) key = z.which;

	if (key == "13" && submitButton != null)
	{
		submitButton.click();
	}
}


//-->
</script>