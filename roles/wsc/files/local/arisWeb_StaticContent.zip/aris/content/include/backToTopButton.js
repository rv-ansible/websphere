<script language="javascript" type="text/javascript">
<!--//
	document.write("<input type='button' value='<bean:message key="button.edtServices.backToTop"/>' tabindex='100' onclick='window.scrollTo(0,0)'/>");
//-->
</script>