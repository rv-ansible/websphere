<script language="JavaScript1.2" type="text/javascript">
<!--//
function change_to_Grey(tag, styleName, colour){
	a = document.getElementsByTagName(tag);
	for(i = 0; i < a.length; i++){
		if(a[i].div  == styleName){
			a[i].style.color = colour;
		} 
	} 
}
function disableOptions(numFirst, numLast, onOff){
	for(i = numFirst; i != numLast; i++){
		document.forms[0].elements[i].disabled = onOff;
	}
}
//-->
</script>