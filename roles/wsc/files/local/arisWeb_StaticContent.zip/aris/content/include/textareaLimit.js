<script language="javascript" type="text/javascript">
<!--//
var ns4 = (document.layers) ? true : false;
function textCount(whichField,numCount) {
	if (whichField.value.length > numCount ) {
		if ((ns4)) {
			numCount = numCount + 1;
			if (whichField.value.length == numCount) {
				alert("Only "+numCount+" characters are permitted in this field.");
			}
		} else {
			whichField.disabled = true;
			alert("Only "+numCount+" characters are permitted in this field.");
			whichField.disabled = false;
			whichField.value = whichField.value.substring( 0, numCount );
			return false;
		}
	}
}
//-->
</script>