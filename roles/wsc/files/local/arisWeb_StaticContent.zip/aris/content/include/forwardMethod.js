<script language="JavaScript" type="text/javascript">
var place = "";
			function changeIt()
			{
				document.location.href = place;
			}
</script>