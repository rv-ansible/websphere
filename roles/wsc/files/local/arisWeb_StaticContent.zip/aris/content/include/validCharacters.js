<script language="javascript" type="text/javascript">
<!--
function showKeyCode(fieldName) {
	for(var i=0; i <  document.forms[0].elements[fieldName].value.length; i++){
		var code = document.forms[0].elements[fieldName].value.charCodeAt(i);
		if ((code <= "31") || (code >= "128")) {
			alert("The character you entered is not a supported ASCII character. Please enter only characters displayed on your keyboard.");
			document.forms[0].elements[fieldName].value="";
			return;
		}
	}	
}
//-->
</script>
