<script language="javascript" type="text/javascript"><!--//
function focusOnName(whichOne){
	document.forms[0].elements[whichOne].focus();
}
//--></script>