<script language="javascript" type="text/javascript">
<!--//
	document.write("<input type='button' value='<bean:message key="button.edtServices.print"/>' tabindex='100' onclick='window.print()'/>");
//-->
</script>